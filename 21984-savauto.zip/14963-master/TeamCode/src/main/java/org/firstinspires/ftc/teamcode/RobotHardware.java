/*
Copyright 2022 FIRST Tech Challenge Team 14963

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

package org.firstinspires.ftc.teamcode;




import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.gamepad1;
import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.hardwareMap;

import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;


public class RobotHardware {
    /* Instantatiate motors and servos */
    // May need to change values due to size change
    public DcMotor frontL;
    public DcMotor backL;
    public DcMotor frontR;
    public DcMotor backR;
    public DcMotor mActuatorLeft;
    public DcMotor mActuatorRight;

    public Servo servoL;
    public Servo servoR;

    public int firstJunction = 1300;
    public int secondJunction = 2265;
    public int thirdJunction = 3000;



    //initalizes all hardware, must be run before movement
    public void init(HardwareMap hardwareMap) {
        // was front L
        frontL = hardwareMap.get(DcMotor.class, "frontmotorL");
        // was backL
        backL = hardwareMap.get(DcMotor.class, "backmotorL");
        // was frontR
        frontR = hardwareMap.get(DcMotor.class, "frontmotorR");
        // was backR
        backR = hardwareMap.get(DcMotor.class, "backmotorR");
        mActuatorLeft = hardwareMap.get(DcMotor.class, "actuatorL");
        mActuatorRight = hardwareMap.get(DcMotor.class, "actuatorR");
        servoL = hardwareMap.get(Servo.class, "servoL");
        servoR = hardwareMap.get(Servo.class, "servoR");

        frontL.setPower(0);
        frontR.setPower(0);
        backL.setPower(0);
        backR.setPower(0);
        mActuatorLeft.setPower(0);
        mActuatorRight.setPower(0);



        frontL.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        frontR.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        backL.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
        backR.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);

        servoL.setPosition(0);
        servoR.setDirection(Servo.Direction.REVERSE);
        servoR.setPosition(0);

    }
    /* TESTING, PRAYING THIS WORKS 1/23/2023 */
    public void plzWork() {
        leftRightAuto(-24, .5);

        frontBackAuto(36, .5);
        // if sees color start stacking/ stop moving/ start slaying
        rotateAuto(90, 0.5);
    }



    //Math original

    public int math(int numOfInches) {
        // 535.3 is average ( May change due to size change)
        final int ticks_per_rotation = 535;

        final double inches_per_rotation = 3.54331 * Math.PI;
        double ticks_per_inch = ticks_per_rotation / inches_per_rotation;
        return numOfInches * (int) ticks_per_inch;
    }

    public double mathFL(double numOfInches) {
        // 535.3 is average
        //535.2 is actual avg
        final double ticks_per_rotation = 535.2;
        final double inches_per_rotation = 3.54331 * Math.PI;
        double ticks_per_inch = ticks_per_rotation / inches_per_rotation;
        return numOfInches * ticks_per_inch;
    }

    public double mathBL(double numOfInches) {
        // 535.3 is average
        //5347 is actual avg
        final double ticks_per_rotation = 535.2;
        final double inches_per_rotation = 3.54331 * Math.PI;
        double ticks_per_inch = ticks_per_rotation / inches_per_rotation;
        return numOfInches * ticks_per_inch;
    }

    public double mathFR(double numOfInches) {
        // 535.3 is average
        //534.6 is actual avg
        final double ticks_per_rotation = 535.2;
        final double inches_per_rotation = 3.54331 * Math.PI;
        double ticks_per_inch = ticks_per_rotation / inches_per_rotation;
        return numOfInches * ticks_per_inch;
    }

    public double mathBR(double numOfInches) {
        // 535.3 is average
        //537.5 is actual avg
        final double ticks_per_rotation = 535.2;
        final double inches_per_rotation = 3.54331 * Math.PI;
        double ticks_per_inch = ticks_per_rotation / inches_per_rotation;
        return numOfInches * ticks_per_inch;
    }





    /*
    Start of Controller Movement Section
    */





    public void movement(double x, double y) {
        //Sets motors to run without encoder
        frontL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        frontR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        //was neg x
        frontL.setPower(y - x);
        // was pos x
        backL.setPower(y + x);
        // was neg y, was pos x
        frontR.setPower((-y) -  x);
        // was neg y, was neg x
        backR.setPower((-y) + x);

    }



    //rotates robot about an axis with Controller
    public void rotateControlled(double value) {
        //sets motors to run without encoder
        frontL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        frontR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backL.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backR.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        frontL.setPower(-value);
        backL.setPower(-value);
        frontR.setPower(-value);
        backR.setPower(-value);
    }

    /*
    End of Controller Movement Section
    Start of Actuator and Claw Section
    */

    public void linearActuator(int targetValue) {

        // was pos
        mActuatorRight.setTargetPosition( targetValue);
        // was neg
        mActuatorLeft.setTargetPosition( targetValue);

        mActuatorRight.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        mActuatorLeft.setMode(DcMotor.RunMode.RUN_TO_POSITION);


        mActuatorLeft.setPower(.5);
        mActuatorRight.setPower(.5);
    }

    public void openClaw() {
        servoL.setPosition(0);
        servoR.setPosition(0);
    }

    public void closeClaw() {
        servoL.setPosition(0.215);
        servoR.setPosition(0.16);
    }



    /*
    End of Actuator and Claw Section
    Start of Autonomous Section
    */














    //moves forward and back autonomously
    public void frontBackAuto(double inches, double powerLvl) {
        frontR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        frontR.setTargetPosition((int) mathFR(inches));
        frontL.setTargetPosition((int)- mathFL(inches));
        backL.setTargetPosition((int)-mathBL(inches));
        backR.setTargetPosition((int) mathBR(inches));
        //sets motors to run using encoder
        frontR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backR.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        frontR.setPower(powerLvl);
        frontL.setPower(powerLvl);
        backL.setPower(powerLvl);
        backR.setPower(powerLvl);
    }



    //moves left and right autonomously
    public void leftRightAuto(double inches, double powerLvl) {
        //Negative inches is left
        frontR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        //sets target position
        // was neg
        frontL.setTargetPosition((int) mathFL(inches));
        // was neg
        frontR.setTargetPosition((int) mathFR(inches));
        // was pos
        backL.setTargetPosition((int)- mathBL(inches));
        // was pos
        backR.setTargetPosition((int)- mathBR(inches));
        //sets motors to run using encoder
        frontL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backR.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        frontL.setPower(powerLvl);
        backL.setPower(powerLvl);
        frontR.setPower(powerLvl);
        backR.setPower(powerLvl);
    }

    public void rotateAuto(int degrees, double powerLvl) {
        //negative degrees goes to the right
        frontR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backL.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        backR.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        final double degree = 1080 / 90;

        frontL.setTargetPosition((int) (degree * degrees));
        frontR.setTargetPosition((int) (degree * degrees));
        backL.setTargetPosition((int) (degree * degrees));
        backR.setTargetPosition((int) (degree * degrees));

        frontL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        frontR.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backL.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        backR.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        frontL.setPower(powerLvl);
        backL.setPower(powerLvl);
        frontR.setPower(powerLvl);
        backR.setPower(powerLvl);
    }

}
